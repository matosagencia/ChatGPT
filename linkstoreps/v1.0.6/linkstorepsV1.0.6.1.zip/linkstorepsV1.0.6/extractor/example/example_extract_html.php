<?php
include_once('../simple_html_dom.php');

echo file_get_html('http://18.210.71.16/oldsite/shopping_dep_12_sec_19.html')->plaintext;
?>