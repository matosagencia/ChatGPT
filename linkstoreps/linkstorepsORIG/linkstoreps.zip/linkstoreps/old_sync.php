<?php

require ('../../config/config.inc.php');
$product = Db::getInstance()->ExecuteS('SELECT * FROM '._DB_PREFIX_.'product');
$count = 0;
foreach($product as $artigos){
    $count ++;
                $id_product = Db::getInstance()->ExecuteS('SELECT * FROM `'._DB_PREFIX_.'linkstoreps` WHERE `CODIGO` LIKE "%'.$artigos['reference'].'%"');
                
                if(!empty($id_product)){
    			    Db::getInstance()->update('linkstoreps',array('id_product' => $artigos['id_product']), '`IDa` = '.$id_product[0]['IDa']);	
    			    echo "Produto Sincronizado com sucesso! ". $artigos['reference'] ."|>|".$artigos['id_product'] ."</br>";
                }
}
$linkstore = Db::getInstance()->ExecuteS('SELECT * FROM '._DB_PREFIX_.'linkstoreps');
foreach($linkstore as $linkst){
$idproduct = Db::getInstance()->getValue('SELECT id_product FROM `'._DB_PREFIX_.'product` WHERE `id_product` = "'.$linkst['id_product'].'"');
                if(empty($idproduct))
    			    Db::getInstance()->update('linkstoreps',array('id_product' => 'null'), '`IDa` = '.$linkst['IDa']);	
    	 		    
}